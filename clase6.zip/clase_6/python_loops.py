from random import *

# # Python Loops

# # Loops con While
# current_lap = 1
# while current_lap <= 26:
#     print(f"Piloto de McLaren va en la vuelta {current_lap}")
#     current_lap += 1

# # Permitir al usuario salir del loop
# car = "bueno"
# current_lap = 1
# while current_lap <= 26 and car == "bueno":
#     print(f"Piloto de McLaren va en la vuelta {current_lap}")
#     car = "malo"
#     current_lap += 1

# # Uso de banderas en un loop
# flag = True
# while flag:
#     status = input("Esta la bandera ondeando? s/n")
#     if status == "s":
#         print("Baje su velocidad")
#     elif status == "n":
#         print("Acelera mi rayo Mqueen")
#         flag = False    

# # Uso del break para salir de un loop
# car = 'bueno'
# current_lap = 1
# while current_lap <= 26 and car == 'bueno':
#     print('Estamos en la vuelta ' + str(current_lap))
#     computer_failure = randrange(9)
#     if computer_failure == 7:
#         print('La computadora ha fallado')
#         break
#     current_lap += 1
# print('Termino la carrera!')

# # Uso del continue dentro loop
# in_race = True
# while in_race:
#     print("Seguimos en la carrera")

#     tires_status = input("Las llantas están bien?")
#     if tires_status == 'no':
#         print("Entrando a pits")
#         print("Cambiando llantas")
#         print("Saliendo de pits")
#         continue
#     else:
#         print("No necesitas entrar a pits")

#     computer_status = input("La computadora esta bien?")
#     if computer_status == 'malo':
#         print("Entrando a pits")
#         print("Arreglando computadora")
#         print("Saliendo de pits")
#         continue
#     else:
#         print("No necesitas entrar a pits")       

    # print("Mantente hidratado y acepera campeon/a")
    # keep_in_race = input("Quiéres seguir en la carrera? s/n")
    # if keep_in_race == "n":
    #     in_race = False


#  # Uso de while loop en listas
# in_race = ['Mercedes','McLaren','Ferrari','Renault','RedBull']
# final_positions = []
# while in_race:
#     racing_car = in_race.pop()
#     print(f"{racing_car} esta cruzando la meta")
#     final_positions.append(racing_car)
# print(final_positions)
# print(in_race)
# in_race2 = ('Mercedes','McLaren','Ferrari','Renault','RedBull')
# in_race2 = list(in_race2)
# print(type(in_race2))
# while in_race2:
#     racing_car = in_race2.pop()
#     print(f"{racing_car} esta cruzando la meta")


# final_positions = ['Mercedes','McLaren','Ferrari','Renault','RedBull']
# while 'Mercedes' in final_positions:
#     final_positions.remove('Mercedes')
#     print("Mercedes due descalificado")
# print("Nueva tabla de lugares")
# print(final_positions)    

# # Uso de loops en diccionarios
# teams = {}
# polling_active = True
# while polling_active:
#     team = input('¿Nombre de la escudería? ')
#     driver = input('¿Nombre del piloto?')
#     teams[team] = driver
#     repeat = input("¿Quiéres agregar otro? s/n  ")
#     if repeat == 'n':
#         polling_active = False
# print(teams)

# Uso de for loop
# teams = ['Mercedes','McLaren','Renault','Williams']
# favorite_teams = []
# for team in teams:
#     if team == "Mercedes":
#         print("Me encanta Mercedes")
#         favorite_teams.append(team)
#     elif team == "Williams":
#         print("Me encanta Williams")
#         favorite_teams.append(team)
#     else:
#         print(f"{team} no me gusta tanto")        
# print(favorite_teams)


# Uso de for loop con diccionarios

# teams = {'Mercedes':'John', 'McLaren':'Roger', 'Williams':'Amy'}
# for team, driver in teams.items():
#     print(f"\nLa escudería de {team} tiene al piloto {driver}")

# for team in teams.keys():
#     print(f"La escudería {team} esta en la competencia")

# for driver in teams.values():
#     print(f"El piloto es {driver}")


# Loops anidados

# teams = {
#     'Mercedes':
#     {
#         'drivers': ['Hugo','Paco','Juana'],
#         'budget': 6000000,
#         'country':'Alemania'
#     },
#     'McLaren':
#     {
#         'drivers': ['Marcela','Pedro','Juan'],
#         'budget': 700000,
#         'country': 'Inglaterra'
#     }
# }

# for team, description in teams.items():
#     print(f"La escudedía {team} tiene")
#     print(f"Un presupuesto de {description['budget']}")
#     print(f"Y es del país {description['country']}")
#     for driver in description['drivers']:
#         print(f"Tiene al piloto {driver}")


