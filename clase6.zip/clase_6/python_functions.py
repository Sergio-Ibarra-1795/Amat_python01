# Python functions

# Creando funciones
def say_hi():
    """ Welcome message """
    print('Hi')

say_hi()

# Argumentos posicionales
def say_hi2(name, lastname):
    """ Custom Welcome message """
    print(f"Hi {name} {lastname}")

say_hi2('pedro','pascal')


# Argumentos por keyword
def say_hi3(name, lastname):
    """ Custom Welcome message """
    print(f"Hi {name} {lastname}")

say_hi3(lastname="pascal", name="pedro")


# Argumentos por default
def say_hi4(name, lastname="clasificado"):
    """ Custom Welcome message """
    print(f"Hi {name} {lastname}")

say_hi4(name="Juan")


# Argumentos opcionales
def say_hi5(name, lastname, job=''):
    """ Custom Welcome message """
    print(f"Hi {name} {lastname}")

say_hi5("Juan","Franchute")


# Argumentos arbitrarios

def create_pizza(*toppings):
    """Create custom pizza for clients"""
    for topping in toppings:
        print(f"Su pizza tiene {topping}")

create_pizza('jamon','piña')


# Retorno de valores

def my_super_sum(value1, value2):
    my_sum = int(value1) + int(value2)
    return my_sum

number = my_super_sum(1,2)

print(number)





























